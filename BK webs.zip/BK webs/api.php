<?php
declare(strict_types=1);

require __DIR__ . '/db.php';

date_default_timezone_set('Asia/Jakarta');
require __DIR__ . '/auth_session.php';
startAppSession();
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store, private');
header('X-Content-Type-Options: nosniff');
header('X-Frame-Options: DENY');
header('Referrer-Policy: strict-origin-when-cross-origin');
header('Permissions-Policy: camera=(), microphone=(), geolocation=()');
header("Content-Security-Policy: default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline' https://fonts.googleapis.com; font-src 'self' https://fonts.gstatic.com data:; img-src 'self' data: blob:; connect-src 'self'; object-src 'none'; base-uri 'self'; form-action 'self'; frame-ancestors 'none'");

function respond($data, int $status = 200): void
{
    http_response_code($status);
    echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

function inputData(): array
{
    if ($_POST) {
        return $_POST;
    }
    $data = json_decode(file_get_contents('php://input'), true);
    return is_array($data) ? $data : [];
}

function requireCsrf(): void
{
    $origin = $_SERVER['HTTP_ORIGIN'] ?? '';
    if ($origin !== '') {
        $originHost = parse_url($origin, PHP_URL_HOST);
        $originScheme = parse_url($origin, PHP_URL_SCHEME);
        $expectedScheme = !empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off' ? 'https' : 'http';
        if (!$originHost || strtolower((string) $originHost) !== strtolower((string) ($_SERVER['HTTP_HOST'] ?? ''))
            || strtolower((string) $originScheme) !== $expectedScheme) {
            respond(['error' => 'Permintaan lintas situs ditolak.'], 403);
        }
    }
    if (($_SERVER['HTTP_SEC_FETCH_SITE'] ?? '') === 'cross-site') {
        respond(['error' => 'Permintaan lintas situs ditolak.'], 403);
    }

    $sent = $_SERVER['HTTP_X_CSRF_TOKEN'] ?? '';
    $stored = $_SESSION['csrf_token'] ?? '';
    if (!$stored || !$sent || !hash_equals($stored, $sent)) {
        respond(['error' => 'Sesi keamanan tidak valid. Muat ulang halaman dan coba lagi.'], 403);
    }
}

function loginAttemptKey(string $username): string
{
    return hash('sha256', strtolower($username) . "\0" . (string) ($_SERVER['REMOTE_ADDR'] ?? 'unknown'));
}

function loginLocked(PDO $pdo, string $key): bool
{
    $query = $pdo->prepare('SELECT locked_until > NOW() FROM login_attempts WHERE attempt_key = ?');
    $query->execute([$key]);
    return (bool) $query->fetchColumn();
}

function recordFailedLogin(PDO $pdo, string $key): bool
{
    $pdo->beginTransaction();
    try {
        $query = $pdo->prepare(
            'INSERT IGNORE INTO login_attempts (attempt_key, attempts, window_started_at)
             VALUES (?, 0, NOW())'
        );
        $query->execute([$key]);
        $query = $pdo->prepare(
            'SELECT attempts, window_started_at FROM login_attempts WHERE attempt_key = ? FOR UPDATE'
        );
        $query->execute([$key]);
        $record = $query->fetch();
        $windowExpired = strtotime((string) $record['window_started_at']) <= time() - 900;
        $attempts = $windowExpired ? 1 : (int) $record['attempts'] + 1;
        $locked = $attempts >= 5;
        $query = $pdo->prepare(
            'UPDATE login_attempts SET attempts = ?, window_started_at = ?,
             locked_until = ? WHERE attempt_key = ?'
        );
        $query->execute([
            $attempts,
            $windowExpired ? date('Y-m-d H:i:s') : $record['window_started_at'],
            $locked ? date('Y-m-d H:i:s', time() + 900) : null,
            $key,
        ]);
        $pdo->commit();
        if (random_int(1, 100) === 1) {
            $pdo->exec('DELETE FROM login_attempts WHERE window_started_at < DATE_SUB(NOW(), INTERVAL 1 DAY)');
        }
        return $locked;
    } catch (Throwable $error) {
        if ($pdo->inTransaction()) {
            $pdo->rollBack();
        }
        throw $error;
    }
}

function currentUser(PDO $pdo): ?array
{
    if (empty($_SESSION['user_id'])) {
        return null;
    }

    $query = $pdo->prepare(
        'SELECT u.id, u.username, u.full_name, u.role, s.id AS student_id, c.name AS class_name,
                pp.photo_path AS profile_photo_path
         FROM users u LEFT JOIN students s ON s.user_id = u.id AND s.is_active = 1
         LEFT JOIN classes c ON c.id = s.class_id
         LEFT JOIN profile_photos pp ON pp.user_id = u.id
         WHERE u.id = ? AND u.is_active = 1 LIMIT 1'
    );
    $query->execute([(int) $_SESSION['user_id']]);
    $user = $query->fetch();
    if (!$user) {
        unset($_SESSION['user_id']);
        return null;
    }

    return [
        'id' => (int) $user['id'],
        'username' => $user['username'],
        'name' => $user['full_name'],
        'role' => $user['role'],
        'studentId' => $user['student_id'] ? (int) $user['student_id'] : null,
        'className' => $user['class_name'],
        'profilePhotoUrl' => $user['profile_photo_path']
            ? 'api.php?action=file&kind=profile&id=' . (int) $user['id'] . '&v=' . rawurlencode(basename($user['profile_photo_path']))
            : null,
    ];
}

function requireUser(PDO $pdo): array
{
    $user = currentUser($pdo);
    if (!$user) {
        respond(['error' => 'Silakan masuk kembali.'], 401);
    }
    return $user;
}

function requireRole(PDO $pdo, array $roles): array
{
    $user = requireUser($pdo);
    if (!in_array($user['role'], $roles, true)) {
        respond(['error' => 'Anda tidak memiliki akses untuk tindakan ini.'], 403);
    }
    return $user;
}

function academicYear(): string
{
    $year = (int) date('Y');
    return date('n') >= 7 ? $year . '/' . ($year + 1) : ($year - 1) . '/' . $year;
}

function classId(PDO $pdo, string $className): int
{
    $allowed = ['X-A', 'X-B', 'X-C', 'X-D', 'X-E', 'X-F', 'XI-MIPA', 'XI-IPS1', 'XI-IPS2', 'XI-IPC1', 'XI-IPC2', 'XI-IPC3'];
    if (!in_array($className, $allowed, true)) {
        respond(['error' => 'Kelas tidak valid.'], 422);
    }

    $query = $pdo->prepare(
        'INSERT INTO classes (name, academic_year) VALUES (?, ?)
         ON DUPLICATE KEY UPDATE id = LAST_INSERT_ID(id)'
    );
    $query->execute([$className, academicYear()]);
    return (int) $pdo->lastInsertId();
}

function studentId(PDO $pdo, string $name, int $classId, ?int $userId = null): int
{
    $name = trim($name);
    if ($name === '' || mb_strlen($name) > 100) {
        respond(['error' => 'Nama siswa wajib diisi (maksimal 100 karakter).'], 422);
    }

    if ($userId !== null) {
        $query = $pdo->prepare('SELECT id FROM students WHERE user_id = ? AND is_active = 1 LIMIT 1');
        $query->execute([$userId]);
        $linkedId = $query->fetchColumn();
        if ($linkedId) {
            return (int) $linkedId;
        }
    }

    $query = $pdo->prepare(
        'SELECT id FROM students WHERE full_name = ? AND class_id = ? AND is_active = 1 ORDER BY id LIMIT 1'
    );
    $query->execute([$name, $classId]);
    $existingId = $query->fetchColumn();
    if ($existingId) {
        return (int) $existingId;
    }

    $query = $pdo->prepare('INSERT INTO students (full_name, class_id, user_id) VALUES (?, ?, ?)');
    $query->execute([$name, $classId, $userId]);
    return (int) $pdo->lastInsertId();
}

function storeUpload(string $field, bool $allowPdf = false): ?array
{
    if (empty($_FILES[$field]) || $_FILES[$field]['error'] === UPLOAD_ERR_NO_FILE) {
        return null;
    }

    $file = $_FILES[$field];
    if ($file['error'] !== UPLOAD_ERR_OK || $file['size'] > 5 * 1024 * 1024) {
        respond(['error' => 'Berkas gagal diunggah atau ukurannya melebihi 5 MB.'], 422);
    }

    $mime = (new finfo(FILEINFO_MIME_TYPE))->file($file['tmp_name']);
    $extensions = ['image/jpeg' => 'jpg', 'image/png' => 'png', 'image/webp' => 'webp'];
    if ($allowPdf) {
        $extensions['application/pdf'] = 'pdf';
    }
    if (!isset($extensions[$mime])) {
        respond(['error' => 'Jenis berkas tidak didukung. Gunakan JPG, PNG, WebP' . ($allowPdf ? ', atau PDF.' : '.'),], 422);
    }

    $directory = __DIR__ . '/uploads';
    if (!is_dir($directory) && !mkdir($directory, 0750, true) && !is_dir($directory)) {
        respond(['error' => 'Folder unggahan tidak dapat dibuat.'], 500);
    }

    $filename = bin2hex(random_bytes(20)) . '.' . $extensions[$mime];
    if (!move_uploaded_file($file['tmp_name'], $directory . '/' . $filename)) {
        respond(['error' => 'Berkas gagal disimpan.'], 500);
    }

    return [
        'path' => 'uploads/' . $filename,
        'name' => basename((string) $file['name']),
        'mime' => $mime,
        'size' => (int) $file['size'],
    ];
}

function absentConsecutiveDays(PDO $pdo, int $studentId, string $date): int
{
    $query = $pdo->prepare(
        "SELECT day FROM (
           SELECT r.report_date AS day FROM attendance_details d
           JOIN attendance_reports r ON r.id = d.report_id
           WHERE d.student_id = ? AND d.status <> 'hadir' AND r.report_date < ?
           UNION ALL
           SELECT absence_date AS day FROM absence_confirmations
           WHERE student_id = ? AND absence_date < ?
         ) AS absence_days ORDER BY day DESC LIMIT 1"
    );
    $query->execute([$studentId, $date, $studentId, $date]);
    $lastDate = $query->fetchColumn();
    if (!$lastDate) {
        return 1;
    }

    $previous = new DateTimeImmutable((string) $lastDate);
    $current = new DateTimeImmutable($date);
    return $previous->diff($current)->days === 1 ? 2 : 1;
}

function findUploadPath(PDO $pdo, array $user, string $kind, int $id): array
{
    if ($kind === 'profile') {
        if ($id !== (int) $user['id']) {
            respond(['error' => 'Anda tidak memiliki akses ke foto profil ini.'], 403);
        }
        $query = $pdo->prepare(
            'SELECT photo_path AS path, photo_mime_type AS mime, photo_original_name AS name
             FROM profile_photos WHERE user_id = ?'
        );
    } elseif ($kind === 'report') {
        requireRole($pdo, ['admin', 'promax']);
        $query = $pdo->prepare('SELECT photo_path AS path, photo_mime_type AS mime, photo_original_name AS name FROM attendance_reports WHERE id = ?');
    } elseif ($kind === 'confirmation') {
        $query = $pdo->prepare('SELECT proof_path AS path, proof_mime_type AS mime, proof_original_name AS name, student_id FROM absence_confirmations WHERE id = ?');
    } else {
        respond(['error' => 'Lampiran tidak ditemukan.'], 404);
    }

    $query->execute([$id]);
    $file = $query->fetch();
    if (!$file || !$file['path']) {
        respond(['error' => 'Lampiran tidak ditemukan.'], 404);
    }
    if ($kind === 'confirmation' && $user['role'] === 'basic' && (int) $file['student_id'] !== (int) $user['studentId']) {
        respond(['error' => 'Anda tidak memiliki akses ke lampiran ini.'], 403);
    }

    return $file;
}

$action = $_GET['action'] ?? '';
$method = $_SERVER['REQUEST_METHOD'] ?? 'GET';

try {
    if ($action === 'file' && $method === 'GET' && isset($_GET['kind'], $_GET['id'])) {
        $user = requireUser($pdo);
        $file = findUploadPath($pdo, $user, (string) $_GET['kind'], (int) $_GET['id']);
        $base = realpath(__DIR__ . '/uploads');
        $path = realpath(__DIR__ . '/' . $file['path']);
        if (!$base || !$path || !str_starts_with($path, $base . DIRECTORY_SEPARATOR) || !is_file($path)) {
            http_response_code(404);
            exit;
        }
        header('Content-Type: ' . ($file['mime'] ?: 'application/octet-stream'));
        header('Content-Length: ' . filesize($path));
        header('Content-Disposition: inline; filename*=UTF-8\'\'' . rawurlencode((string) $file['name']));
        header('X-Content-Type-Options: nosniff');
        readfile($path);
        exit;
    }

    if ($action === 'session' && $method === 'GET') {
        $_SESSION['csrf_token'] ??= bin2hex(random_bytes(32));
        respond(['user' => currentUser($pdo), 'csrfToken' => $_SESSION['csrf_token']]);
    }

    if ($method !== 'POST' && !($action === 'dashboard' && $method === 'GET')) {
        respond(['error' => 'Metode permintaan tidak didukung.'], 405);
    }
    if ($method === 'POST') {
        requireCsrf();
    }

    if ($action === 'login') {
        $input = inputData();
        $username = strtolower(trim((string) ($input['username'] ?? '')));
        $attemptKey = loginAttemptKey($username);
        if (loginLocked($pdo, $attemptKey)) {
            respond(['error' => 'Terlalu banyak percobaan masuk. Coba kembali dalam 15 menit.'], 429);
        }
        $query = $pdo->prepare('SELECT id, username, password_hash, is_active FROM users WHERE username = ? LIMIT 1');
        $query->execute([$username]);
        $account = $query->fetch();
        if (!$account || !(int) $account['is_active'] || !password_verify((string) ($input['password'] ?? ''), $account['password_hash'])) {
            if (recordFailedLogin($pdo, $attemptKey)) {
                respond(['error' => 'Terlalu banyak percobaan masuk. Coba kembali dalam 15 menit.'], 429);
            }
            respond(['error' => 'Username atau kata sandi tidak cocok.'], 401);
        }

        $query = $pdo->prepare('DELETE FROM login_attempts WHERE attempt_key = ?');
        $query->execute([$attemptKey]);
        session_regenerate_id(true);
        $_SESSION['user_id'] = (int) $account['id'];
        $_SESSION['created_at'] = time();
        $_SESSION['last_activity'] = time();
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
        respond(['user' => currentUser($pdo), 'csrfToken' => $_SESSION['csrf_token']]);
    }

    if ($action === 'logout') {
        requireUser($pdo);
        $_SESSION = [];
        if (ini_get('session.use_cookies')) {
            $cookie = session_get_cookie_params();
            setcookie(session_name(), '', [
                'expires' => time() - 42000,
                'path' => $cookie['path'],
                'domain' => $cookie['domain'],
                'secure' => $cookie['secure'],
                'httponly' => $cookie['httponly'],
                'samesite' => $cookie['samesite'],
            ]);
        }
        session_destroy();
        respond(['ok' => true]);
    }

    if ($action === 'profile') {
        $user = requireUser($pdo);
        $input = inputData();
        $name = trim((string) ($input['name'] ?? ''));
        $currentPassword = (string) ($input['currentPassword'] ?? '');
        $newPassword = (string) ($input['newPassword'] ?? '');
        if ($name === '' || mb_strlen($name) > 100) {
            respond(['error' => 'Nama wajib diisi dan maksimal 100 karakter.'], 422);
        }

        $credentialsChanged = $currentPassword !== '' || $newPassword !== '';
        if ($credentialsChanged) {
            $query = $pdo->prepare('SELECT password_hash FROM users WHERE id = ?');
            $query->execute([$user['id']]);
            if (!password_verify($currentPassword, (string) $query->fetchColumn())) {
                respond(['error' => 'Kata sandi saat ini tidak cocok.'], 422);
            }
            if ($newPassword !== '' && (mb_strlen($newPassword) < 12 || strlen($newPassword) > 72)) {
                respond(['error' => 'Kata sandi baru harus 12 karakter atau lebih dan maksimal 72 byte.'], 422);
            }
        }

        if ($newPassword !== '') {
            $query = $pdo->prepare('UPDATE users SET full_name = ?, password_hash = ? WHERE id = ?');
            $query->execute([$name, password_hash($newPassword, PASSWORD_DEFAULT), $user['id']]);
            session_regenerate_id(true);
            $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
        } else {
            $query = $pdo->prepare('UPDATE users SET full_name = ? WHERE id = ?');
            $query->execute([$name, $user['id']]);
        }
        $query = $pdo->prepare('UPDATE students SET full_name = ? WHERE user_id = ?');
        $query->execute([$name, $user['id']]);
        respond([
            'user' => currentUser($pdo),
            'csrfToken' => $_SESSION['csrf_token'],
        ]);
    }

    if ($action === 'profile-photo') {
        $user = requireUser($pdo);
        $uploaded = storeUpload('photo');
        if (!$uploaded) {
            respond(['error' => 'Pilih foto profil terlebih dahulu.'], 422);
        }

        $storedPath = __DIR__ . '/' . $uploaded['path'];
        $imageInfo = @getimagesize($storedPath);
        if ($imageInfo === false || $imageInfo[0] * $imageInfo[1] > 25000000) {
            if (is_file($storedPath) && !unlink($storedPath)) {
                error_log('Failed to remove an invalid profile photo upload.');
            }
            respond(['error' => 'Foto tidak valid atau resolusinya terlalu besar.'], 422);
        }

        try {
            $pdo->beginTransaction();
            $query = $pdo->prepare('SELECT photo_path FROM profile_photos WHERE user_id = ? FOR UPDATE');
            $query->execute([$user['id']]);
            $previousPath = $query->fetchColumn() ?: null;
            $query = $pdo->prepare(
                'INSERT INTO profile_photos (user_id, photo_path, photo_original_name, photo_mime_type, photo_size_bytes)
                 VALUES (?, ?, ?, ?, ?)
                 ON DUPLICATE KEY UPDATE photo_path = VALUES(photo_path),
                    photo_original_name = VALUES(photo_original_name),
                    photo_mime_type = VALUES(photo_mime_type),
                    photo_size_bytes = VALUES(photo_size_bytes)'
            );
            $query->execute([$user['id'], $uploaded['path'], $uploaded['name'], $uploaded['mime'], $uploaded['size']]);
            $pdo->commit();
        } catch (Throwable $error) {
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }
            if (is_file($storedPath) && !unlink($storedPath)) {
                error_log('Failed to remove an uncommitted profile photo upload.');
            }
            throw $error;
        }

        if ($previousPath && $previousPath !== $uploaded['path']) {
            $uploadsDirectory = realpath(__DIR__ . '/uploads');
            $previousFile = realpath(__DIR__ . '/' . $previousPath);
            if ($uploadsDirectory && $previousFile
                && str_starts_with($previousFile, $uploadsDirectory . DIRECTORY_SEPARATOR)
                && is_file($previousFile) && !unlink($previousFile)) {
                error_log('Failed to remove a replaced profile photo.');
            }
        }

        respond(['user' => currentUser($pdo)]);
    }

    if ($action === 'dashboard') {
        $user = requireRole($pdo, ['admin', 'promax']);
        $reports = $pdo->query(
            "SELECT r.id, r.report_date, c.name AS class_name, u.full_name AS reporter,
                    r.status, r.created_at, r.photo_original_name
             FROM attendance_reports r
             JOIN classes c ON c.id = r.class_id
             JOIN users u ON u.id = r.reporter_user_id
             ORDER BY r.report_date DESC, r.id DESC"
        )->fetchAll();
        $details = $pdo->query(
            'SELECT d.report_id, d.student_id, s.full_name, d.status FROM attendance_details d
             JOIN students s ON s.id = d.student_id ORDER BY d.id'
        )->fetchAll();
        $detailsByReport = [];
        foreach ($details as $detail) {
            $detailsByReport[$detail['report_id']][] = [
                'studentId' => (int) $detail['student_id'],
                'name' => $detail['full_name'],
                'status' => match ($detail['status']) {
                    'hadir' => 'Hadir', 'sakit' => 'Sakit', 'izin' => 'Izin', default => 'Tanpa keterangan',
                },
            ];
        }
        $reports = array_map(static function (array $report) use ($detailsByReport): array {
            return [
                'id' => (int) $report['id'],
                'date' => $report['report_date'],
                'className' => $report['class_name'],
                'reporter' => $report['reporter'],
                'status' => $report['status'] === 'verified' ? 'Terverifikasi' : 'Menunggu verifikasi',
                'timestamp' => $report['created_at'],
                'photoName' => $report['photo_original_name'],
                'photoUrl' => 'api.php?action=file&kind=report&id=' . (int) $report['id'],
                'students' => $detailsByReport[$report['id']] ?? [],
            ];
        }, $reports);

        $confirmations = $pdo->query(
            "SELECT ac.id, s.full_name AS name, c.name AS class_name, ac.reason,
                    ac.absence_date, ac.submitted_at, ac.proof_original_name,
                    ac.status, ac.student_id
             FROM absence_confirmations ac
             JOIN students s ON s.id = ac.student_id
             JOIN classes c ON c.id = ac.class_id
             ORDER BY ac.submitted_at DESC"
        )->fetchAll();
        $confirmations = array_map(static function (array $item): array {
            $reasons = ['sakit' => 'Sakit', 'izin' => 'Izin', 'lainnya' => 'Keterangan lainnya', 'tanpa_keterangan' => 'Tanpa keterangan'];
            return [
                'id' => (int) $item['id'], 'name' => $item['name'], 'className' => $item['class_name'],
                'reason' => $reasons[$item['reason']] ?? $item['reason'], 'date' => $item['absence_date'],
                'timestamp' => $item['submitted_at'], 'proofName' => $item['proof_original_name'],
                'proofUrl' => $item['proof_original_name'] ? 'api.php?action=file&kind=confirmation&id=' . (int) $item['id'] : null,
                'status' => $item['status'] === 'verified' ? 'Terverifikasi' : 'Menunggu verifikasi',
                'studentId' => (int) $item['student_id'],
            ];
        }, $confirmations);

        $query = $pdo->prepare(
            "SELECT s.id AS student_id, s.full_name AS student, c.name AS class_name,
                    COUNT(*) AS count, GROUP_CONCAT(DATE_FORMAT(t.occurred_at, '%Y-%m-%d') ORDER BY t.occurred_at) AS dates,
                    MAX(t.occurred_at) AS last_at, tf.status AS followup_status
             FROM tardiness_records t
             JOIN students s ON s.id = t.student_id
             JOIN classes c ON c.id = s.class_id
             LEFT JOIN tardiness_followups tf ON tf.student_id = s.id AND tf.academic_year = ?
             GROUP BY s.id, s.full_name, c.name, tf.status
             ORDER BY last_at DESC"
        );
        $query->execute([academicYear()]);
        $lateRecords = array_map(static function (array $item): array {
            return [
                'studentId' => (int) $item['student_id'], 'student' => $item['student'],
                'className' => $item['class_name'], 'count' => (int) $item['count'],
                'dates' => $item['dates'] ? explode(',', $item['dates']) : [],
                'lastAt' => $item['last_at'],
                'followUp' => $item['followup_status'] === 'approved' ? 'Pemanggilan disetujui'
                    : ((int) $item['count'] >= 3 ? 'Notifikasi ke tim kesiswaan' : 'Belum ditindaklanjuti'),
            ];
        }, $query->fetchAll());

        $users = [];
        if ($user['role'] === 'promax') {
            $users = $pdo->query(
                'SELECT id, full_name AS name, role, username FROM users WHERE is_active = 1 ORDER BY full_name'
            )->fetchAll();
            $users = array_map(static fn(array $item): array => [
                'id' => (int) $item['id'], 'name' => $item['name'], 'role' => $item['role'], 'username' => $item['username'],
            ], $users);
        }

        respond(['reports' => $reports, 'confirmations' => $confirmations, 'lateRecords' => $lateRecords, 'users' => $users]);
    }

    if ($action === 'report-create') {
        $user = requireRole($pdo, ['admin', 'promax']);
        $className = trim((string) ($_POST['className'] ?? ''));
        $date = (string) ($_POST['date'] ?? '');
        $students = json_decode((string) ($_POST['students'] ?? '[]'), true);
        if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $date) || !is_array($students) || !$students || count($students) > 100) {
            respond(['error' => 'Tanggal atau daftar siswa tidak valid.'], 422);
        }
        $uploaded = storeUpload('photo');
        if (!$uploaded) {
            respond(['error' => 'Foto kondisi kelas wajib diunggah.'], 422);
        }

        try {
            $pdo->beginTransaction();
            $class = classId($pdo, $className);
            $query = $pdo->prepare(
                'INSERT INTO attendance_reports
                 (class_id, report_date, reporter_user_id, photo_path, photo_original_name, photo_mime_type, photo_size_bytes)
                 VALUES (?, ?, ?, ?, ?, ?, ?)'
            );
            $query->execute([$class, $date, $user['id'], $uploaded['path'], $uploaded['name'], $uploaded['mime'], $uploaded['size']]);
            $reportId = (int) $pdo->lastInsertId();
            $insert = $pdo->prepare('INSERT INTO attendance_details (report_id, student_id, status) VALUES (?, ?, ?)');
            $statusMap = ['Hadir' => 'hadir', 'Sakit' => 'sakit', 'Izin' => 'izin', 'Tanpa keterangan' => 'tanpa_keterangan'];
            foreach ($students as $student) {
                $name = trim((string) ($student['name'] ?? ''));
                $status = $statusMap[(string) ($student['status'] ?? '')] ?? null;
                if (!$status) {
                    throw new RuntimeException('Status absensi tidak valid.');
                }
                $id = studentId($pdo, $name, $class);
                $insert->execute([$reportId, $id, $status]);
            }
            $pdo->commit();
        } catch (Throwable $error) {
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }
            @unlink(__DIR__ . '/' . $uploaded['path']);
            throw $error;
        }
        respond(['ok' => true]);
    }

    if ($action === 'report-verify') {
        $user = requireRole($pdo, ['admin', 'promax']);
        $input = inputData();
        $query = $pdo->prepare("UPDATE attendance_reports SET status = 'verified', verified_by = ?, verified_at = NOW() WHERE id = ?");
        $query->execute([$user['id'], (int) ($input['id'] ?? 0)]);
        respond(['ok' => true]);
    }

    if ($action === 'confirmation-create') {
        $user = requireUser($pdo);
        $input = inputData();
        if ($user['role'] === 'basic') {
            if (!$user['studentId']) {
                respond(['error' => 'Akun ini belum terhubung ke data siswa. Hubungi Admin ProMax.'], 422);
            }
            $student = $pdo->prepare(
                'SELECT s.id, s.full_name, s.class_id, c.name AS class_name FROM students s
                 JOIN classes c ON c.id = s.class_id WHERE s.id = ?'
            );
            $student->execute([$user['studentId']]);
            $student = $student->fetch();
            $studentKey = (int) $student['id'];
            $name = $student['full_name'];
            $class = (int) $student['class_id'];
            $className = $student['class_name'];
        } else {
            $name = trim((string) ($input['name'] ?? ''));
            $className = trim((string) ($input['className'] ?? ''));
            $class = classId($pdo, $className);
            $studentKey = studentId($pdo, $name, $class);
        }

        $date = date('Y-m-d');
        $consecutive = absentConsecutiveDays($pdo, $studentKey, $date);
        $uploaded = storeUpload('proof', true);
        if ($consecutive >= 2 && !$uploaded) {
            respond(['error' => 'Unggah surat dokter untuk ketidakhadiran dua hari berturut-turut.'], 422);
        }
        $reasonMap = ['Sakit' => 'sakit', 'Izin' => 'izin', 'Keterangan lainnya' => 'lainnya', 'Tanpa keterangan' => 'tanpa_keterangan'];
        $reason = $reasonMap[(string) ($input['reason'] ?? '')] ?? null;
        if (!$reason) {
            if ($uploaded) {
                @unlink(__DIR__ . '/' . $uploaded['path']);
            }
            respond(['error' => 'Keterangan ketidakhadiran tidak valid.'], 422);
        }

        $query = $pdo->prepare(
            'INSERT INTO absence_confirmations
             (student_id, class_id, absence_date, reason, proof_path, proof_original_name, proof_mime_type, proof_size_bytes)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?)'
        );
        $query->execute([
            $studentKey, $class, $date, $reason, $uploaded['path'] ?? null, $uploaded['name'] ?? null,
            $uploaded['mime'] ?? null, $uploaded['size'] ?? null,
        ]);
        respond(['ok' => true, 'consecutiveDays' => $consecutive]);
    }

    if ($action === 'confirmation-verify') {
        $user = requireRole($pdo, ['admin', 'promax']);
        $input = inputData();
        $query = $pdo->prepare("UPDATE absence_confirmations SET status = 'verified', verified_by = ?, verified_at = NOW() WHERE id = ?");
        $query->execute([$user['id'], (int) ($input['id'] ?? 0)]);
        respond(['ok' => true]);
    }

    if ($action === 'late-create') {
        $user = requireRole($pdo, ['admin', 'promax']);
        $input = inputData();
        $class = classId($pdo, trim((string) ($input['className'] ?? '')));
        $student = studentId($pdo, (string) ($input['name'] ?? ''), $class);
        $query = $pdo->prepare('INSERT INTO tardiness_records (student_id, recorded_by_user_id) VALUES (?, ?)');
        $query->execute([$student, $user['id']]);

        $query = $pdo->prepare('SELECT COUNT(*) FROM tardiness_records WHERE student_id = ?');
        $query->execute([$student]);
        if ((int) $query->fetchColumn() >= 3) {
            $query = $pdo->prepare(
                "INSERT INTO tardiness_followups (student_id, academic_year, status, updated_by)
                 VALUES (?, ?, 'needed', ?)
                 ON DUPLICATE KEY UPDATE student_id = VALUES(student_id)"
            );
            $query->execute([$student, academicYear(), $user['id']]);
        }
        respond(['ok' => true]);
    }

    if ($action === 'late-followup') {
        $user = requireRole($pdo, ['admin', 'promax']);
        $input = inputData();
        $query = $pdo->prepare(
            "INSERT INTO tardiness_followups (student_id, academic_year, status, updated_by)
             VALUES (?, ?, 'approved', ?)
             ON DUPLICATE KEY UPDATE status = 'approved', updated_by = VALUES(updated_by)"
        );
        $query->execute([(int) ($input['studentId'] ?? 0), academicYear(), $user['id']]);
        respond(['ok' => true]);
    }

    if ($action === 'user-create') {
        requireRole($pdo, ['promax']);
        $input = inputData();
        $username = strtolower(trim((string) ($input['username'] ?? '')));
        $name = trim((string) ($input['name'] ?? ''));
        $password = (string) ($input['password'] ?? '');
        $role = (string) ($input['role'] ?? '');
        if (!preg_match('/^[a-z0-9._-]{3,50}$/', $username) || $name === '' || mb_strlen($name) > 100
            || mb_strlen($password) < 12 || strlen($password) > 72 || !in_array($role, ['basic', 'admin', 'promax'], true)) {
            respond(['error' => 'Data akun tidak valid. Username minimal 3 karakter dan kata sandi harus 12 karakter atau lebih (maksimal 72 byte).'], 422);
        }
        try {
            $pdo->beginTransaction();
            $query = $pdo->prepare('INSERT INTO users (username, password_hash, full_name, role) VALUES (?, ?, ?, ?)');
            $query->execute([$username, password_hash($password, PASSWORD_DEFAULT), $name, $role]);
            $newUserId = (int) $pdo->lastInsertId();
            if ($role === 'basic') {
                $class = classId($pdo, trim((string) ($input['className'] ?? '')));
                studentId($pdo, $name, $class, $newUserId);
            }
            $pdo->commit();
        } catch (PDOException $error) {
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }
            if ((string) $error->getCode() === '23000') {
                respond(['error' => 'Username sudah digunakan.'], 409);
            }
            throw $error;
        }
        respond(['ok' => true]);
    }

    if ($action === 'user-update') {
        $user = requireRole($pdo, ['promax']);
        $input = inputData();
        $id = (int) ($input['id'] ?? 0);
        $name = trim((string) ($input['name'] ?? ''));
        $role = (string) ($input['role'] ?? '');
        if (!$id || $name === '' || mb_strlen($name) > 100 || !in_array($role, ['basic', 'admin', 'promax'], true)) {
            respond(['error' => 'Data akun tidak valid.'], 422);
        }
        if ($id === $user['id'] && $role !== 'promax') {
            respond(['error' => 'Peran akun yang sedang digunakan tidak dapat diturunkan.'], 422);
        }
        $query = $pdo->prepare('SELECT role FROM users WHERE id = ? AND is_active = 1');
        $query->execute([$id]);
        $existingRole = $query->fetchColumn();
        if ($existingRole === 'promax' && $role !== 'promax') {
            $query = $pdo->prepare('SELECT COUNT(*) FROM users WHERE role = "promax" AND is_active = 1 AND id <> ?');
            $query->execute([$id]);
            if ((int) $query->fetchColumn() === 0) {
                respond(['error' => 'Peran Admin ProMax terakhir tidak dapat dihapus. Tambahkan admin lain terlebih dahulu.'], 422);
            }
        }
        $pdo->beginTransaction();
        $query = $pdo->prepare('UPDATE users SET full_name = ?, role = ? WHERE id = ? AND is_active = 1');
        $query->execute([$name, $role, $id]);
        $query = $pdo->prepare('UPDATE students SET full_name = ? WHERE user_id = ?');
        $query->execute([$name, $id]);
        if ($role === 'basic') {
            $query = $pdo->prepare('SELECT id FROM students WHERE user_id = ? AND is_active = 1');
            $query->execute([$id]);
            if (!$query->fetchColumn()) {
                $class = classId($pdo, 'X-A');
                studentId($pdo, $name, $class, $id);
            }
        }
        $pdo->commit();
        respond(['ok' => true]);
    }

    if ($action === 'user-delete') {
        $user = requireRole($pdo, ['promax']);
        $input = inputData();
        $id = (int) ($input['id'] ?? 0);
        if (!$id || $id === $user['id']) {
            respond(['error' => 'Akun ini tidak dapat dinonaktifkan.'], 422);
        }
        $query = $pdo->prepare('SELECT role, is_active FROM users WHERE id = ?');
        $query->execute([$id]);
        $account = $query->fetch();
        if (!$account || !(int) $account['is_active']) {
            respond(['error' => 'Akun tidak ditemukan atau sudah nonaktif.'], 404);
        }
        if ($account['role'] === 'promax') {
            $query = $pdo->prepare('SELECT COUNT(*) FROM users WHERE role = "promax" AND is_active = 1 AND id <> ?');
            $query->execute([$id]);
            if ((int) $query->fetchColumn() === 0) {
                respond(['error' => 'Admin ProMax terakhir tidak dapat dinonaktifkan. Tambahkan admin lain terlebih dahulu.'], 422);
            }
        }
        $query = $pdo->prepare('UPDATE users SET is_active = 0 WHERE id = ?');
        $query->execute([$id]);
        respond(['ok' => true]);
    }

    respond(['error' => 'Aksi tidak ditemukan.'], 404);
} catch (Throwable $error) {
    error_log($error->getMessage());
    respond(['error' => 'Terjadi kesalahan pada server. Periksa log PHP.'], 500);
}