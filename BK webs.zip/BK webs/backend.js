/* Tema siang/malam: memuat theme.js otomatis jika belum dipasang di HTML */
if (location.protocol === 'file:') {
  const localProject = decodeURIComponent(location.pathname).match(/^\/[A-Za-z]:\/xampp\/htdocs\/(.+)$/i);
  if (localProject) {
    const appPath = localProject[1].split('/').map(encodeURIComponent).join('/');
    location.replace(`http://localhost/${appPath}${location.search}${location.hash}`);
  }
}

(function () {
  if (document.querySelector('script[src*="theme.js"]')) return;
  var script = document.createElement('script');
  script.src = 'theme.js';
  document.head.appendChild(script);
})();

const API_URL = 'api.php?action=';
const ROLE_LABELS = { basic: 'Basic User', admin: 'Admin', promax: 'Admin ProMax' };
const pageUrl = view => `page.php?view=${encodeURIComponent(view)}`;
let currentUser = null;
let csrfToken = '';
let dashboardData = { reports: [], confirmations: [], lateRecords: [], users: [] };

const escapeHtml = value => String(value ?? '').replace(/[&<>"']/g, char => ({
  '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
}[char]));

const today = () => {
  const date = new Date();
  return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}-${String(date.getDate()).padStart(2, '0')}`;
};

async function apiRequest(action, { method = 'GET', data, form } = {}) {
  const headers = {};
  if (method !== 'GET') headers['X-CSRF-Token'] = csrfToken;
  if (data !== undefined) headers['Content-Type'] = 'application/json';
  const response = await fetch(`${API_URL}${encodeURIComponent(action)}`, {
    method,
    headers,
    credentials: 'same-origin',
    body: form || (data !== undefined ? JSON.stringify(data) : undefined),
  });
  let payload;
  try { payload = await response.json(); }
  catch { throw new Error('Server tidak mengirim respons yang valid. Pastikan Apache dan PHP berjalan.'); }
  if (!response.ok) throw new Error(payload.error || 'Permintaan gagal.');
  if (payload.csrfToken) csrfToken = payload.csrfToken;
  if (payload.user !== undefined) currentUser = payload.user;
  return payload;
}

function showError(message, target = document.getElementById('err')) {
  if (target) {
    target.hidden = false;
    target.textContent = message;
  } else {
    alert(message);
  }
}

function renderMenu() {
  const host = document.getElementById('layout-nav');
  if (!host || !currentUser) return;
  const basicMenu = currentUser.role === 'basic';
  const activeView = new URLSearchParams(location.search).get('view') || 'index';
  host.innerHTML = `<header class="topbar"><div class="wrap bar">
    <a class="brand" href="${pageUrl(basicMenu ? 'presensi' : 'index')}"><span class="logo">BK</span><span>Ruang BK<small>Absensi & kesiswaan</small></span></a>
    <div class="user"><a class="user-avatar-link" href="${pageUrl('profil')}" aria-label="Buka profil saya"><span class="avatar"><span class="avatar-initial">${escapeHtml(currentUser.name.trim().charAt(0).toUpperCase())}</span><img class="avatar-photo" alt="" hidden></span></a><a class="user-profile-name" href="${pageUrl('profil')}" aria-label="Buka profil saya"><b>${escapeHtml(currentUser.name)}</b><small>${ROLE_LABELS[currentUser.role]}</small></a>
      <div class="theme-control"><span class="theme-control-label">Tema</span><button class="theme-toggle" type="button" role="switch" aria-label="Ganti tema" aria-checked="false"><span class="knob"></span></button></div>
      <button class="btn ghost small" id="logout" type="button">Keluar</button></div></div></header>
    <nav class="menubar"><div class="wrap">
      ${basicMenu ? `<a class="on" href="${pageUrl('presensi')}#konfirmasi">Izin tidak hadir</a>` : `<a class="${activeView === 'index' ? 'on' : ''}" href="${pageUrl('index')}">Ringkasan</a>
      <a class="${activeView === 'presensi' ? 'on' : ''}" href="${pageUrl('presensi')}">Absensi kelas</a>
      <a href="${pageUrl('presensi')}#konfirmasi">Konfirmasi siswa</a>`}
      ${currentUser.role !== 'basic' ? `<a href="${pageUrl('presensi')}#terlambat">Keterlambatan</a>` : ''}
      <a class="${activeView === 'profil' ? 'on' : ''}" href="${pageUrl('profil')}">Profil saya</a>
      ${currentUser.role === 'promax' ? '<span class="nav-role">Pengelolaan akses</span>' : ''}
    </div></nav>`;
  document.getElementById('logout').addEventListener('click', async () => {
    try { await apiRequest('logout', { method: 'POST', data: {} }); }
    finally { location.href = 'index.html'; }
  });
  document.dispatchEvent(new Event('ruangbk:menu-rendered'));
  updateAvatar(document.querySelector('#layout-nav .avatar'), currentUser.name, currentUser.profilePhotoUrl);
}

function setupLogin() {
  const form = document.getElementById('formLogin');
  if (!form) return;
  if (currentUser) {
    location.replace(pageUrl(currentUser.role === 'basic' ? 'presensi' : 'index'));
    return;
  }
  document.getElementById('lihat')?.addEventListener('click', event => {
    const password = document.getElementById('password');
    password.type = password.type === 'password' ? 'text' : 'password';
    event.currentTarget.textContent = password.type === 'password' ? 'Lihat' : 'Tutup';
  });
  form.addEventListener('submit', async event => {
    event.preventDefault();
    const error = document.getElementById('err');
    error.hidden = true;
    try {
      await apiRequest('login', {
        method: 'POST',
        data: { username: form.elements.username.value.trim(), password: form.elements.password.value },
      });
      location.href = pageUrl(currentUser.role === 'basic' ? 'presensi' : 'index');
    } catch (requestError) {
      showError(requestError.message, error);
    }
  });
}

function setupLoginMascot() {
  const mascot = document.getElementById('loginMascot');
  if (!mascot || mascot.dataset.pointerTracking === 'true'
    || window.matchMedia('(prefers-reduced-motion: reduce)').matches) return;
  mascot.dataset.pointerTracking = 'true';

  let pointerX = window.innerWidth / 2;
  let pointerY = window.innerHeight / 2;

  const updateEyes = () => {
    const bounds = mascot.getBoundingClientRect();
    const centerX = bounds.left + bounds.width / 2;
    const centerY = bounds.top + bounds.height / 2;
    const angle = Math.atan2(pointerY - centerY, pointerX - centerX);
    const distance = Math.min(1, Math.hypot(pointerX - centerX, pointerY - centerY) / 260);
    const offset = distance * 5;
    mascot.style.setProperty('--look-x', `${Math.cos(angle) * offset}px`);
    mascot.style.setProperty('--look-y', `${Math.sin(angle) * offset}px`);
  };

  const trackPointer = event => {
    pointerX = event.clientX;
    pointerY = event.clientY;
    updateEyes();
  };

  updateEyes();
  window.addEventListener('pointermove', trackPointer, { passive: true });
  window.addEventListener('pointerleave', () => {
    pointerX = window.innerWidth / 2;
    pointerY = window.innerHeight / 2;
    updateEyes();
  }, { passive: true });
}

function updateAvatar(container, name, photoUrl) {
  if (!container) return;
  const initial = container.querySelector('.avatar-initial');
  const photo = container.querySelector('.avatar-photo');
  if (initial) {
    initial.textContent = name.trim().charAt(0).toUpperCase() || '?';
    initial.hidden = Boolean(photoUrl);
  }
  if (photo) {
    if (photoUrl) {
      photo.src = photoUrl;
      photo.hidden = false;
      photo.onerror = () => {
        photo.hidden = true;
        if (initial) initial.hidden = false;
      };
    } else {
      photo.removeAttribute('src');
      photo.hidden = true;
    }
  }
}

function setupProfile() {
  const form = document.getElementById('profileForm');
  if (!form || !currentUser) return;
  document.getElementById('profileName').value = currentUser.name;
  document.getElementById('profileUsername').value = currentUser.username;
  document.getElementById('profileRole').value = ROLE_LABELS[currentUser.role];
  updateAvatar(document.getElementById('profileAvatar'), currentUser.name, currentUser.profilePhotoUrl);
  document.getElementById('profileSummaryName').textContent = currentUser.name;
  document.getElementById('profileSummaryRole').textContent = ROLE_LABELS[currentUser.role];
  document.getElementById('profileSummaryUsername').textContent = currentUser.username;

  form.addEventListener('submit', async event => {
    event.preventDefault();
    const message = document.getElementById('profileMessage');
    message.hidden = true;
    try {
      const passwordChanged = document.getElementById('newPassword').value !== '';
      const result = await apiRequest('profile', {
        method: 'POST',
        data: {
          name: document.getElementById('profileName').value.trim(),
          currentPassword: document.getElementById('currentPassword').value,
          newPassword: document.getElementById('newPassword').value,
        },
      });
      currentUser = result.user;
      updateAvatar(document.getElementById('profileAvatar'), currentUser.name, currentUser.profilePhotoUrl);
      document.getElementById('profileSummaryName').textContent = currentUser.name;
      message.classList.add('success-message');
      message.textContent = passwordChanged ? 'Profil dan kata sandi berhasil diperbarui.'
        : 'Nama profil berhasil diperbarui.';
      document.getElementById('currentPassword').value = '';
      document.getElementById('newPassword').value = '';
      renderMenu();
    } catch (error) {
      message.classList.remove('success-message');
      message.textContent = error.message;
    }
    message.hidden = false;
  });

  const photoInput = document.getElementById('profilePhotoInput');
  const photoChoose = document.getElementById('profilePhotoChoose');
  const photoMessage = document.getElementById('profilePhotoMessage');
  const photoHint = document.getElementById('profilePhotoHint');
  let previewUrl = '';
  let photoUploadInProgress = false;
  updateAvatar(document.getElementById('profileAvatar'), currentUser.name, currentUser.profilePhotoUrl);

  photoChoose.addEventListener('click', () => photoInput.click());

  photoInput.addEventListener('change', async () => {
    const file = photoInput.files[0];
    if (!file || photoUploadInProgress) return;

    const extension = file.name.split('.').pop().toLowerCase();
    const allowedTypes = ['image/jpeg', 'image/png', 'image/webp'];
    const allowedExtensions = ['jpg', 'jpeg', 'png', 'webp'];
    if ((!allowedTypes.includes(file.type) && !(file.type === '' && allowedExtensions.includes(extension)))
      || file.size > 5 * 1024 * 1024) {
      photoInput.value = '';
      photoHint.textContent = 'Pilih foto untuk langsung memperbarui profil.';
      photoMessage.textContent = 'Foto tidak didukung atau lebih dari 5 MB. Gunakan JPG, PNG, atau WebP.';
      photoMessage.classList.remove('success-message');
      photoMessage.classList.add('photo-error');
      return;
    }

    if (previewUrl) URL.revokeObjectURL(previewUrl);
    photoHint.textContent = file.name;
    previewUrl = URL.createObjectURL(file);
    updateAvatar(document.getElementById('profileAvatar'), currentUser.name, previewUrl);
    photoUploadInProgress = true;
    photoChoose.disabled = true;
    photoInput.disabled = true;
    photoMessage.classList.remove('success-message');
    photoMessage.classList.remove('photo-error');
    photoMessage.textContent = 'Foto dipilih. Sedang menyimpan...';
    const body = new FormData();
    body.append('photo', file);
    try {
      const result = await apiRequest('profile-photo', { method: 'POST', form: body });
      currentUser = result.user;
      updateAvatar(document.getElementById('profileAvatar'), currentUser.name, currentUser.profilePhotoUrl);
      updateAvatar(document.querySelector('#layout-nav .avatar'), currentUser.name, currentUser.profilePhotoUrl);
      photoInput.value = '';
      photoHint.textContent = 'JPG, PNG, atau WebP · Maksimal 5 MB';
      if (previewUrl) URL.revokeObjectURL(previewUrl);
      previewUrl = '';
      photoMessage.textContent = 'Foto profil berhasil diperbarui.';
      photoMessage.classList.add('success-message');
      photoMessage.classList.remove('photo-error');
    } catch (error) {
      photoInput.value = '';
      photoMessage.textContent = `Foto belum tersimpan: ${error.message}`;
      photoMessage.classList.add('photo-error');
      updateAvatar(document.getElementById('profileAvatar'), currentUser.name, previewUrl || currentUser.profilePhotoUrl);
    } finally {
      photoUploadInProgress = false;
      photoChoose.disabled = false;
      photoInput.disabled = false;
    }
  });
}

const ATTENDANCE_STATUSES = [
  { key: 'Hadir', className: 'present', label: 'Hadir' },
  { key: 'Sakit', className: 'sick', label: 'Sakit' },
  { key: 'Izin', className: 'permission', label: 'Izin' },
  { key: 'Tanpa keterangan', className: 'unexcused', label: 'Tanpa keterangan' },
  { key: 'Keterangan lainnya', className: 'other', label: 'Lainnya' },
];

function renderAttendanceChart() {
  const chart = document.getElementById('attendanceChart');
  if (!chart) return;

  const range = Number(document.getElementById('attendanceRange')?.value) === 30 ? 30 : 7;
  const endDate = new Date();
  endDate.setHours(0, 0, 0, 0);
  const days = Array.from({ length: range }, (_, index) => {
    const date = new Date(endDate);
    date.setDate(date.getDate() - (range - index - 1));
    const key = `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}-${String(date.getDate()).padStart(2, '0')}`;
    return { date, key, counts: Object.fromEntries(ATTENDANCE_STATUSES.map(status => [status.key, 0])) };
  });
  const dayByKey = new Map(days.map(day => [day.key, day]));
  const seenStudentsByDay = new Map(days.map(day => [day.key, new Set()]));
  const studentKey = (item, fallback) => item.studentId ? `id:${item.studentId}` : fallback;

  dashboardData.reports.forEach(report => {
    const day = dayByKey.get(report.date);
    if (!day) return;
    report.students.forEach(student => {
      const status = ATTENDANCE_STATUSES.find(item => item.key === student.status);
      if (!status) return;
      const identity = studentKey(student, `${report.className}|${student.name}`.trim().toLocaleLowerCase('id-ID'));
      const seen = seenStudentsByDay.get(day.key);
      if (seen.has(identity)) return;
      seen.add(identity);
      day.counts[status.key]++;
    });
  });

  dashboardData.confirmations.forEach(item => {
    const day = dayByKey.get(item.date);
    if (!day) return;
    const fallback = `${item.className}|${item.name}`.trim().toLocaleLowerCase('id-ID');
    const identity = studentKey(item, fallback);
    const seen = seenStudentsByDay.get(day.key);
    if (seen.has(identity)) return;
    const status = ATTENDANCE_STATUSES.find(candidate => candidate.key === item.reason)
      || ATTENDANCE_STATUSES.find(candidate => candidate.key === 'Keterangan lainnya');
    seen.add(identity);
    day.counts[status.key]++;
  });

  const maxTotal = Math.max(1, ...days.map(day => Object.values(day.counts).reduce((sum, count) => sum + count, 0)));
  const totalCount = days.reduce((sum, day) => sum + Object.values(day.counts).reduce((daySum, count) => daySum + count, 0), 0);
  const chartHeight = 150;
  const dateFormatter = new Intl.DateTimeFormat('id-ID', range === 7
    ? { weekday: 'short', day: 'numeric' }
    : { day: 'numeric', month: 'short' });

  chart.style.minWidth = range === 7 ? '100%' : `${range * 38}px`;
  chart.style.gridTemplateColumns = `repeat(${range}, minmax(0, 1fr))`;
  chart.innerHTML = days.map((day, index) => {
    const total = Object.values(day.counts).reduce((sum, count) => sum + count, 0);
    const height = total ? Math.max(4, Math.round(total / maxTotal * chartHeight)) : 0;
    const segments = ATTENDANCE_STATUSES.filter(status => day.counts[status.key] > 0).map(status =>
      `<span class="attendance-segment ${status.className}" style="height:${day.counts[status.key] / total * 100}%" title="${status.label}: ${day.counts[status.key]}"></span>`
    ).join('');
    const label = dateFormatter.format(day.date);
    return `<div class="attendance-day" title="${day.key}" style="--bar-delay:${Math.min(index, 14) * 35}ms">
      <span class="attendance-day-total">${total || ''}</span>
      <div class="attendance-bar-area"><div class="attendance-bar" style="height:${height}px">${segments}</div></div>
      <span class="attendance-day-label">${escapeHtml(label)}</span>
    </div>`;
  }).join('');

  const empty = document.getElementById('attendanceChartEmpty');
  if (empty) empty.hidden = totalCount > 0;
  const figure = chart.closest('.attendance-figure');
  if (figure) figure.hidden = totalCount === 0;
  const totalLabel = document.getElementById('attendanceChartTotal');
  if (totalLabel) totalLabel.textContent = `${totalCount} catatan kehadiran dalam ${range} hari terakhir`;
  const summary = document.getElementById('attendanceChartSummary');
  if (summary) {
    summary.textContent = `Grafik ${range} hari terakhir, total ${totalCount} catatan. ${days.map(day => {
      const label = new Intl.DateTimeFormat('id-ID', { weekday: 'long', day: 'numeric', month: 'long' }).format(day.date);
      const details = ATTENDANCE_STATUSES.filter(status => day.counts[status.key] > 0)
        .map(status => `${status.label} ${day.counts[status.key]}`).join(', ');
      return `${label}: ${details || 'tidak ada catatan'}`;
    }).join('. ')}.`;
  }
}

function renderDashboard() {
  const hour = new Date().getHours();
  const greeting = document.getElementById('sapa');
  if (greeting) greeting.textContent = `${hour < 11 ? 'Selamat pagi' : hour < 15 ? 'Selamat siang' : hour < 18 ? 'Selamat sore' : 'Selamat malam'}, ${currentUser.name}`;
  const reports = dashboardData.reports;
  const todayReports = reports.filter(report => report.date === today());
  const absentStudentKeys = new Set();
  const addAbsentStudent = (studentId, name, className) => {
    const key = studentId ? `id:${studentId}` : `${className.toLowerCase()}|${name.toLowerCase()}`;
    absentStudentKeys.add(key);
  };
  todayReports.forEach(report => report.students
    .filter(student => student.status !== 'Hadir')
    .forEach(student => addAbsentStudent(student.studentId, student.name, report.className)));
  dashboardData.confirmations
    .filter(item => item.date === today())
    .forEach(item => addAbsentStudent(item.studentId, item.name, item.className));
  const late = dashboardData.lateRecords;
  const set = (id, value) => { const element = document.getElementById(id); if (element) element.textContent = value; };
  set('statReports', todayReports.length);
  set('statAbsent', absentStudentKeys.size);
  set('statLate', late.reduce((total, item) => total + item.dates.filter(date => date === today()).length, 0));
  set('statPending', todayReports.filter(report => report.status === 'Menunggu verifikasi').length);
  const dateLabel = document.getElementById('todayLabel');
  if (dateLabel) dateLabel.textContent = new Date().toLocaleDateString('id-ID', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' });
  renderAttendanceChart();

  const rows = document.getElementById('reportRows');
  if (rows) rows.innerHTML = reports.slice(0, 6).map(report => `<tr>
    <td>${escapeHtml(report.date)}</td><td>${escapeHtml(report.className)}</td><td>${escapeHtml(report.reporter)}</td>
    <td>${report.students.filter(student => student.status !== 'Hadir').length}</td>
    <td><span class="status">${escapeHtml(report.status)}</span></td>
    <td><button class="text-link" type="button" data-detail="${report.id}">Rincian</button>
      ${report.status === 'Menunggu verifikasi' ? `<button class="text-link" type="button" data-verify="${report.id}">Verifikasi</button>` : 'Terverifikasi'}</td></tr>`).join('')
    || '<tr><td colspan="6" class="empty">Belum ada laporan kelas.</td></tr>';

  const confirmationRows = document.getElementById('confirmationRows');
  if (confirmationRows) confirmationRows.innerHTML = dashboardData.confirmations.map(item => `<tr>
    <td>${escapeHtml(item.name)}</td><td>${escapeHtml(item.className)}</td><td>${escapeHtml(item.reason)}</td>
    <td>${escapeHtml(new Date(item.timestamp).toLocaleString('id-ID'))}</td>
    <td>${item.proofUrl ? `<a class="text-link" href="${escapeHtml(item.proofUrl)}" target="_blank" rel="noopener">Lihat bukti</a>` : '—'}</td>
    <td><span class="status ${item.status === 'Terverifikasi' ? 'good' : ''}">${escapeHtml(item.status)}</span></td>
    <td>${item.status === 'Terverifikasi' ? 'Selesai' : `<button class="text-link" type="button" data-verify-confirm="${item.id}">Verifikasi</button>`}</td></tr>`).join('')
    || '<tr><td colspan="7" class="empty">Belum ada konfirmasi siswa.</td></tr>';

  document.querySelectorAll('[data-admin-only]').forEach(element => { element.hidden = false; });
  document.querySelectorAll('[data-promax-only]').forEach(element => { element.hidden = currentUser.role !== 'promax'; });
  const users = document.getElementById('userRows');
  if (users && currentUser.role === 'promax') users.innerHTML = dashboardData.users.map(item => `<tr>
    <td><input aria-label="Nama ${escapeHtml(item.username)}" data-edit-name="${item.id}" value="${escapeHtml(item.name)}"></td>
    <td><select aria-label="Peran ${escapeHtml(item.username)}" data-edit-role="${item.id}">
      <option value="basic" ${item.role === 'basic' ? 'selected' : ''}>Basic User</option>
      <option value="admin" ${item.role === 'admin' ? 'selected' : ''}>Admin</option>
      <option value="promax" ${item.role === 'promax' ? 'selected' : ''}>Admin ProMax</option></select></td>
    <td>${escapeHtml(item.username)}</td><td><button class="text-link" type="button" data-save-user="${item.id}">Simpan</button>
      <button class="icon-button" type="button" data-delete-user="${item.id}">Nonaktifkan</button></td></tr>`).join('');

  const alerts = document.getElementById('alertList');
  if (alerts) {
    const active = late.filter(item => item.count >= 3 && item.followUp !== 'Pemanggilan disetujui');
    alerts.innerHTML = active.map(item => `<li><b>${escapeHtml(item.student)}</b> (${escapeHtml(item.className)}) tercatat terlambat ${item.count} kali.
      <span>${escapeHtml(item.followUp)}</span> <button class="text-link" type="button" data-follow-up="${item.studentId}">Konfirmasi pemanggilan</button></li>`).join('')
      || '<li class="empty">Belum ada peringatan kesiswaan.</li>';
  }
}

async function loadDashboard() {
  dashboardData = await apiRequest('dashboard');
  renderDashboard();
}

function setupDashboardEvents() {
  document.getElementById('attendanceRange')?.addEventListener('change', renderAttendanceChart);
  const newUserRole = document.getElementById('newUserRole');
  const newUserClass = document.getElementById('newUserClass');
  const newUserClassField = document.getElementById('newUserClassField');
  const updateClassRequirement = () => {
    const needsClass = newUserRole?.value === 'basic';
    if (newUserClassField) newUserClassField.hidden = !needsClass;
    if (newUserClass) newUserClass.required = Boolean(needsClass);
  };
  newUserRole?.addEventListener('change', updateClassRequirement);
  updateClassRequirement();

  document.getElementById('reportRows')?.addEventListener('click', async event => {
    const detailButton = event.target.closest('[data-detail]');
    if (detailButton) {
      const report = dashboardData.reports.find(item => item.id === Number(detailButton.dataset.detail));
      if (!report) return;
      document.getElementById('reportDetailTitle').textContent = `${report.className} · ${report.date}`;
      document.getElementById('reportDetailMeta').textContent = `Dilaporkan oleh ${report.reporter} pada ${new Date(report.timestamp).toLocaleString('id-ID')}`;
      document.getElementById('reportStudentRows').innerHTML = report.students.map(student => `<li><span>${escapeHtml(student.name)}</span><span class="status ${student.status === 'Hadir' ? 'good' : 'warn'}">${escapeHtml(student.status)}</span></li>`).join('');
      const proofWrap = document.getElementById('reportProofWrap');
      proofWrap.hidden = !report.photoUrl;
      if (report.photoUrl) {
        document.getElementById('reportProofImage').src = report.photoUrl;
        const download = document.getElementById('reportProofDownload');
        download.href = report.photoUrl;
        download.download = (report.photoName || 'foto-kelas').replace(/\.[^.]+$/, '.jpg');
      }
      document.getElementById('reportDialog').showModal();
      return;
    }
    const verifyButton = event.target.closest('[data-verify]');
    if (verifyButton) {
      try { await apiRequest('report-verify', { method: 'POST', data: { id: Number(verifyButton.dataset.verify) } }); await loadDashboard(); }
      catch (error) { showError(error.message); }
    }
  });

  document.getElementById('confirmationRows')?.addEventListener('click', async event => {
    const button = event.target.closest('[data-verify-confirm]');
    if (!button) return;
    try { await apiRequest('confirmation-verify', { method: 'POST', data: { id: Number(button.dataset.verifyConfirm) } }); await loadDashboard(); }
    catch (error) { showError(error.message); }
  });

  document.getElementById('userForm')?.addEventListener('submit', async event => {
    event.preventDefault();
    try {
      await apiRequest('user-create', {
        method: 'POST',
        data: {
          name: document.getElementById('newUserName').value.trim(),
          username: document.getElementById('newUsername').value.trim(),
          role: document.getElementById('newUserRole').value,
          password: document.getElementById('newUserPassword').value,
          className: document.getElementById('newUserClass')?.value,
        },
      });
      event.currentTarget.reset();
      await loadDashboard();
    } catch (error) { showError(error.message); }
  });

  document.getElementById('userRows')?.addEventListener('click', async event => {
    const save = event.target.closest('[data-save-user]');
    const remove = event.target.closest('[data-delete-user]');
    const id = Number(save?.dataset.saveUser || remove?.dataset.deleteUser);
    if (!id) return;
    try {
      if (save) {
        await apiRequest('user-update', {
          method: 'POST',
          data: {
            id,
            name: document.querySelector(`[data-edit-name="${id}"]`).value.trim(),
            role: document.querySelector(`[data-edit-role="${id}"]`).value,
          },
        });
      } else {
        if (!confirm('Nonaktifkan akun ini? Pengguna tidak dapat masuk, tetapi riwayat datanya tetap tersimpan.')) return;
        await apiRequest('user-delete', { method: 'POST', data: { id } });
      }
      await loadDashboard();
    } catch (error) { showError(error.message); }
  });

  document.getElementById('alertList')?.addEventListener('click', async event => {
    const button = event.target.closest('[data-follow-up]');
    if (!button || !confirm('Apakah tim kesiswaan, orang tua, dan wali kelas telah menyetujui pemanggilan?')) return;
    try {
      await apiRequest('late-followup', { method: 'POST', data: { studentId: Number(button.dataset.followUp) } });
      await loadDashboard();
    } catch (error) { showError(error.message); }
  });
}

function setupReportForm() {
  const form = document.getElementById('reportForm');
  if (!form) return;
  if (currentUser.role === 'basic') {
    document.getElementById('laporan').hidden = true;
    document.title = 'Izin Tidak Hadir | Ruang BK';
    document.querySelector('.page-heading h1').textContent = 'Izin tidak hadir';
    document.querySelector('.page-heading .muted').textContent = 'Sampaikan ketidakhadiran Anda kepada wali kelas dengan keterangan yang sesuai.';
    document.querySelector('#konfirmasi .eyebrow').textContent = 'PENGAJUAN IZIN SISWA';
    document.querySelector('#konfirmasi h2').textContent = 'Formulir izin ketidakhadiran';
    document.querySelector('#konfirmasi .section-copy').textContent = 'Isi keterangan ketidakhadiran Anda. Waktu pengajuan dicatat otomatis untuk ditinjau wali kelas.';
    document.getElementById('confirmName').value = currentUser.name;
    document.getElementById('confirmName').readOnly = true;
    const classInput = document.getElementById('confirmClass');
    if (currentUser.className) classInput.value = currentUser.className;
    classInput.disabled = true;
    document.getElementById('confirmReason').innerHTML = '<option>Sakit</option><option>Izin</option><option>Tanpa keterangan</option>';
    document.querySelector('#confirmForm button[type="submit"]').innerHTML = 'Kirim izin <span>→</span>';
    document.getElementById('terlambat').hidden = true;
  }

  const roster = [];
  const studentName = document.getElementById('studentName');
  const rosterRows = document.getElementById('rosterRows');
  const renderRoster = () => {
    rosterRows.innerHTML = roster.map((student, index) => `<li>
      <span>${escapeHtml(student.name)}</span><span class="status ${student.status === 'Hadir' ? 'good' : 'warn'}">${escapeHtml(student.status)}</span>
      <button type="button" class="icon-button" data-remove="${index}" aria-label="Hapus ${escapeHtml(student.name)}">Hapus</button></li>`).join('')
      || '<li class="empty">Tambahkan siswa untuk mulai mengisi daftar hadir.</li>';
  };
  const addStudent = () => {
    const name = studentName.value.trim();
    if (!name) return;
    roster.push({ name, status: document.getElementById('studentStatus').value });
    studentName.value = '';
    renderRoster();
  };
  document.getElementById('addStudent').addEventListener('click', addStudent);
  studentName.addEventListener('keydown', event => { if (event.key === 'Enter') { event.preventDefault(); addStudent(); } });
  rosterRows.addEventListener('click', event => {
    const button = event.target.closest('[data-remove]');
    if (button) { roster.splice(Number(button.dataset.remove), 1); renderRoster(); }
  });
  form.addEventListener('submit', async event => {
    event.preventDefault();
    if (!roster.length) { alert('Tambahkan minimal satu siswa ke daftar hadir.'); return; }
    const photo = document.getElementById('classPhoto').files[0];
    if (!photo) { alert('Unggah foto kondisi kelas sebelum mengirim laporan.'); return; }
    const body = new FormData();
    body.append('className', document.getElementById('className').value);
    body.append('date', document.getElementById('reportDate').value);
    body.append('students', JSON.stringify(roster));
    body.append('photo', photo);
    try {
      await apiRequest('report-create', { method: 'POST', form: body });
      alert('Laporan kelas berhasil disimpan.');
      location.href = pageUrl('index');
    } catch (error) { showError(error.message); }
  });
  document.getElementById('reportDate').value = today();
  renderRoster();
}

function setupConfirmationForm() {
  const form = document.getElementById('confirmForm');
  if (!form) return;
  form.addEventListener('submit', async event => {
    event.preventDefault();
    const body = new FormData();
    body.append('name', document.getElementById('confirmName').value.trim());
    body.append('className', document.getElementById('confirmClass').value);
    body.append('reason', document.getElementById('confirmReason').value);
    const proof = document.getElementById('doctorLetter').files[0];
    if (proof) body.append('proof', proof);
    try {
      const result = await apiRequest('confirmation-create', { method: 'POST', form: body });
      alert(`Konfirmasi tercatat pada ${new Date().toLocaleString('id-ID')}${result.consecutiveDays >= 2 ? '. Serahkan juga surat fisik kepada wali kelas saat kembali.' : ''}`);
      form.reset();
      if (currentUser.role === 'basic') {
        document.getElementById('confirmName').value = currentUser.name;
        document.getElementById('confirmClass').value = currentUser.className || '';
      }
    } catch (error) { showError(error.message); }
  });
}

function setupLateForm() {
  const form = document.getElementById('lateForm');
  if (!form || currentUser.role === 'basic') return;
  form.addEventListener('submit', async event => {
    event.preventDefault();
    try {
      await apiRequest('late-create', {
        method: 'POST',
        data: {
          name: document.getElementById('lateStudent').value.trim(),
          className: document.getElementById('lateClass').value,
        },
      });
      form.reset();
      alert('Catatan keterlambatan tersimpan. Tindak lanjut diperlukan setelah tiga catatan.');
    } catch (error) { showError(error.message); }
  });
}

async function boot() {
  const pageName = location.pathname.split('/').pop() || 'page.php';
  const view = new URLSearchParams(location.search).get('view') || 'index';
  const session = await apiRequest('session');
  currentUser = session.user;
  if (pageName === 'index.html') {
    setupLogin();
    return;
  }
  if (!currentUser) {
    document.body.classList.add('auth-pending');
    location.replace('index.html');
    return;
  }
  if (currentUser.role === 'basic' && view === 'index') {
    document.body.classList.add('auth-pending');
    location.replace(pageUrl('presensi'));
    return;
  }

  document.body.classList.remove('auth-pending');
  document.body.classList.toggle('basic-user', currentUser.role === 'basic');
  renderMenu();
  setupProfile();
  setupReportForm();
  setupConfirmationForm();
  setupLateForm();
  if (view === 'index') {
    setupDashboardEvents();
    await loadDashboard();
  }
}

if (location.protocol !== 'file:') {
  if (document.getElementById('formLogin')) setupLoginMascot();
  boot().catch(error => {
    const loginError = document.getElementById('err');
    showError(error.message, loginError);
  });
}