<?php
declare(strict_types=1);

if (PHP_SAPI !== 'cli') {
    http_response_code(404);
    exit;
}

require __DIR__ . '/db.php';

$pdo->exec(
    'CREATE TABLE IF NOT EXISTS profile_photos (
        user_id BIGINT UNSIGNED NOT NULL,
        photo_path VARCHAR(500) NOT NULL,
        photo_original_name VARCHAR(255) NOT NULL,
        photo_mime_type VARCHAR(100) NOT NULL,
        photo_size_bytes BIGINT UNSIGNED NOT NULL,
        updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        PRIMARY KEY (user_id),
        CONSTRAINT fk_profile_photos_user FOREIGN KEY (user_id) REFERENCES users (id)
            ON UPDATE CASCADE ON DELETE CASCADE
    ) ENGINE=InnoDB'
);

$pdo->exec(
    'CREATE TABLE IF NOT EXISTS login_attempts (
        attempt_key CHAR(64) NOT NULL,
        attempts SMALLINT UNSIGNED NOT NULL DEFAULT 0,
        window_started_at DATETIME NOT NULL,
        locked_until DATETIME NULL,
        PRIMARY KEY (attempt_key),
        KEY idx_login_attempts_window (window_started_at)
    ) ENGINE=InnoDB'
);

$year = (int) date('Y');
$academicYear = date('n') >= 7 ? $year . '/' . ($year + 1) : ($year - 1) . '/' . $year;
$classNames = ['X-A', 'X-B', 'X-C', 'X-D', 'X-E', 'X-F', 'XI-MIPA', 'XI-IPS1', 'XI-IPS2', 'XI-IPC1', 'XI-IPC2', 'XI-IPC3'];
$initialUsername = strtolower(trim((string) (getenv('BK_INITIAL_ADMIN_USERNAME') ?: '')));
$initialName = trim((string) (getenv('BK_INITIAL_ADMIN_NAME') ?: ''));
$initialPassword = (string) (getenv('BK_INITIAL_ADMIN_PASSWORD') ?: '');
$hasInitialAdminConfig = $initialUsername !== '' || $initialName !== '' || $initialPassword !== '';
if ($hasInitialAdminConfig
    && (!preg_match('/^[a-z0-9._-]{3,50}$/', $initialUsername)
        || $initialName === '' || mb_strlen($initialName) > 100
        || mb_strlen($initialPassword) < 16 || strlen($initialPassword) > 72)) {
    fwrite(STDERR, "Konfigurasi admin awal tidak valid. Isi username, nama, dan kata sandi 16-72 byte.\n");
    exit(1);
}

$pdo->beginTransaction();
try {
    $classInsert = $pdo->prepare(
        'INSERT INTO classes (name, academic_year) VALUES (?, ?)
         ON DUPLICATE KEY UPDATE id = LAST_INSERT_ID(id)'
    );
    foreach ($classNames as $className) {
        $classInsert->execute([$className, $academicYear]);
    }

    $userCount = (int) $pdo->query('SELECT COUNT(*) FROM users WHERE is_active = 1')->fetchColumn();
    if ($userCount === 0 && $hasInitialAdminConfig) {
        $userInsert = $pdo->prepare(
            'INSERT INTO users (username, password_hash, full_name, role)
             VALUES (?, ?, ?, "promax")'
        );
        $userInsert->execute([
            $initialUsername,
            password_hash($initialPassword, PASSWORD_DEFAULT),
            $initialName,
        ]);
    }

    $pdo->commit();
    echo "Setup selesai. Tabel dan data yang sudah ada dipertahankan.\n";
    if ($userCount === 0 && !$hasInitialAdminConfig) {
        echo "Belum ada akun. Atur BK_INITIAL_ADMIN_USERNAME, BK_INITIAL_ADMIN_NAME, dan BK_INITIAL_ADMIN_PASSWORD (16-72 byte), lalu jalankan setup kembali.\n";
    } elseif ($userCount > 0) {
        echo "Akun admin awal tidak dibuat karena database sudah memiliki pengguna.\n";
    } else {
        echo "Akun Admin ProMax awal berhasil dibuat.\n";
    }
} catch (Throwable $error) {
    $pdo->rollBack();
    fwrite(STDERR, "Setup gagal: {$error->getMessage()}\n");
    exit(1);
}