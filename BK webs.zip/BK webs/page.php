<?php
declare(strict_types=1);

require __DIR__ . '/db.php';
require __DIR__ . '/auth_session.php';
startAppSession();
header('Cache-Control: no-store, private');

$pages = [
    'index' => 'menu.html',
    'presensi' => 'presensi.html',
    'profil' => 'profil.html',
];
$view = $_GET['view'] ?? 'index';
if (!is_string($view) || !isset($pages[strtolower($view)])) {
    http_response_code(404);
    exit('Halaman tidak ditemukan.');
}
$view = strtolower($view);

$userId = $_SESSION['user_id'] ?? null;
if (!$userId) {
    header('Location: index.html', true, 302);
    exit;
}

$query = $pdo->prepare('SELECT role FROM users WHERE id = ? AND is_active = 1 LIMIT 1');
$query->execute([(int) $userId]);
$user = $query->fetch();
if (!$user) {
    $_SESSION = [];
    session_regenerate_id(true);
    header('Location: index.html', true, 302);
    exit;
}
if ($user['role'] === 'basic' && $view === 'index') {
    header('Location: page.php?view=presensi', true, 302);
    exit;
}

$pagePath = __DIR__ . '/' . $pages[$view];
if (!is_file($pagePath) || !is_readable($pagePath)) {
    error_log('Protected application page is missing or unreadable: ' . $pages[$view]);
    http_response_code(500);
    exit('Halaman tidak dapat ditampilkan.');
}

header('Content-Type: text/html; charset=utf-8');
header('Pragma: no-cache');
readfile($pagePath);
