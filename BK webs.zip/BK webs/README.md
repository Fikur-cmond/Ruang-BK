# Ruang BK

## Instalasi lokal
1. Jalankan Apache dan MySQL di XAMPP, lalu impor `database.sql` ke MySQL.
2. Dari PowerShell, siapkan kredensial Admin ProMax pertama dan jalankan setup. Kata sandi diminta tanpa ditampilkan dan tidak ditulis langsung ke riwayat perintah:

   ```powershell
   $env:BK_INITIAL_ADMIN_USERNAME = Read-Host "Username admin awal"
   $env:BK_INITIAL_ADMIN_NAME = Read-Host "Nama admin awal"
   $securePassword = Read-Host "Kata sandi acak (16-72 byte)" -AsSecureString
   $passwordPointer = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($securePassword)
   try {
       $env:BK_INITIAL_ADMIN_PASSWORD = [Runtime.InteropServices.Marshal]::PtrToStringBSTR($passwordPointer)
       C:\xampp\php\php.exe "C:\xampp\htdocs\BK webs\setup.php"
   } finally {
       Remove-Item Env:BK_INITIAL_ADMIN_USERNAME, Env:BK_INITIAL_ADMIN_NAME, Env:BK_INITIAL_ADMIN_PASSWORD -ErrorAction SilentlyContinue
       [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($passwordPointer)
       $securePassword.Dispose()
   }
   ```

   Setup tidak membuat akun otomatis, tidak mengubah akun yang sudah ada, dan tidak menampilkan kata sandi.
3. Buka `http://localhost/BK%20webs/`. Jangan membuka halaman langsung melalui `file://`.
4. Jika database sudah berisi akun, jalankan kembali setup untuk membuat tabel keamanan dan foto profil tanpa menghapus data.

## Pengamanan sebelum dipakai sungguhan
- Sajikan aplikasi melalui HTTPS. `HttpOnly`, `SameSite=Strict`, dan atribut `Secure` pada cookie sesi aktif otomatis saat HTTPS digunakan.
- Ganti semua kata sandi lama dari halaman Profil. Kata sandi akun minimal 12 karakter (maksimal 72 byte); akun awal minimal 16 karakter (maksimal 72 byte).
- Untuk server produksi, gunakan akun MySQL khusus aplikasi dengan hak akses minimum. Simpan konfigurasi database di environment server, jangan di repositori.
- Batasi akses server ke jaringan sekolah, buat cadangan database dan `uploads`, dan selalu perbarui PHP serta MySQL.
- Berkas unggahan dilindungi dari akses langsung dan dilayani melalui endpoint yang memeriksa sesi serta izin pengguna.
- Halaman Masuk tersedia melalui `index.html`. Halaman Ringkasan disimpan sebagai `menu.html`; Ringkasan, Absensi, dan Profil disajikan melalui pemeriksaan sesi server, dan akses langsung ke berkas HTML-nya ditolak.
