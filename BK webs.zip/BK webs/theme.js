/* Ruang BK — theme.js
   1. Mode siang/malam (disimpan di browser, default mengikuti perangkat)
   2. Tombol ganti mode di taskbar (dan di halaman masuk)
   3. Pil penanda menu yang meluncur + taskbar mengecil saat scroll
   Pasang di <head> SEBELUM <link rel="stylesheet" href="app.css"> agar tidak berkedip. */
(function () {
  'use strict';
  if (window.__ruangBkTheme) return;
  window.__ruangBkTheme = true;

  var KEY = 'ruangbk-theme';
  var root = document.documentElement;
  var mq = window.matchMedia ? window.matchMedia('(prefers-color-scheme: light)') : null;
  var reduceMq = window.matchMedia ? window.matchMedia('(prefers-reduced-motion: reduce)') : null;

  function stored() {
    try { var v = localStorage.getItem(KEY); return v === 'light' || v === 'dark' ? v : null; }
    catch (e) { return null; }
  }
  function system() { return mq && mq.matches ? 'light' : 'dark'; }

  /* ---------- Tema ---------- */
  function syncLabels() {
    var light = root.getAttribute('data-theme') === 'light';
    var buttons = document.querySelectorAll('.theme-toggle');
    for (var i = 0; i < buttons.length; i++) {
      buttons[i].setAttribute('aria-checked', light ? 'true' : 'false');
      buttons[i].setAttribute('aria-label', light ? 'Mode siang aktif. Ganti ke mode malam' : 'Mode malam aktif. Ganti ke mode siang');
      buttons[i].title = light ? 'Ganti ke mode malam' : 'Ganti ke mode siang';
    }
  }

  function apply(theme) {
    root.setAttribute('data-theme', theme);
    root.style.colorScheme = theme;
    var meta = document.querySelector('meta[name="theme-color"]');
    if (meta) meta.setAttribute('content', theme === 'light' ? '#eef3fb' : '#060a13');
    syncLabels();
  }

  function switchTheme(next, origin) {
    try { localStorage.setItem(KEY, next); } catch (e) {}
    var reduce = reduceMq && reduceMq.matches;

    if (document.startViewTransition && !reduce && origin) {
      var radius = Math.hypot(
        Math.max(origin.x, window.innerWidth - origin.x),
        Math.max(origin.y, window.innerHeight - origin.y)
      );
      var transition = document.startViewTransition(function () { apply(next); });
      transition.ready.then(function () {
        root.animate(
          { clipPath: [
            'circle(0px at ' + origin.x + 'px ' + origin.y + 'px)',
            'circle(' + radius + 'px at ' + origin.x + 'px ' + origin.y + 'px)'
          ] },
          { duration: 700, easing: 'cubic-bezier(.22, 1, .36, 1)', pseudoElement: '::view-transition-new(root)' }
        );
      }).catch(function () {});
      return;
    }

    root.classList.add('theme-switching');
    apply(next);
    setTimeout(function () { root.classList.remove('theme-switching'); }, 600);
  }

  apply(stored() || system());

  if (mq) {
    var onSystemChange = function () { if (!stored()) apply(system()); };
    if (mq.addEventListener) mq.addEventListener('change', onSystemChange);
    else if (mq.addListener) mq.addListener(onSystemChange);
  }

  /* ---------- Tombol ---------- */
  var ICON_MOON = '<svg class="i-moon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M21 12.8A9 9 0 1 1 11.2 3a7 7 0 0 0 9.8 9.8z"/></svg>';
  var ICON_SUN = '<svg class="i-sun" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M2 12h2M20 12h2M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4"/></svg>';

  function makeToggle(floating) {
    var button = document.createElement('button');
    button.type = 'button';
    button.className = 'theme-toggle' + (floating ? ' floating' : '');
    button.setAttribute('role', 'switch');
    button.innerHTML = '<span class="knob">' + ICON_MOON + ICON_SUN + '</span>';
    bindToggle(button);
    return button;
  }

  function bindToggle(button) {
    if (!button.querySelector('.knob')) {
      button.innerHTML = '<span class="knob">' + ICON_MOON + ICON_SUN + '</span>';
    } else if (!button.querySelector('.i-moon') || !button.querySelector('.i-sun')) {
      button.querySelector('.knob').innerHTML = ICON_MOON + ICON_SUN;
    }
    if (button._themeToggleBound) return;
    button._themeToggleBound = true;
    button.addEventListener('click', function () {
      var rect = button.getBoundingClientRect();
      var next = root.getAttribute('data-theme') === 'light' ? 'dark' : 'light';
      switchTheme(next, { x: rect.left + rect.width / 2, y: rect.top + rect.height / 2 });
    });
  }

  function makeThemeControl() {
    var control = document.createElement('div');
    var label = document.createElement('span');
    control.className = 'theme-control';
    label.className = 'theme-control-label';
    label.textContent = 'Tema';
    control.appendChild(label);
    control.appendChild(makeToggle(false));
    return control;
  }

  /* ---------- Pil penanda menu ---------- */
  function bindPill(wrap, pill) {
    function activeLink() { return wrap.querySelector('a.on'); }

    function place(link, instant) {
      if (!link) { pill.classList.remove('ready'); return; }
      var jump = instant || !pill.classList.contains('ready');
      if (jump) pill.style.transition = 'none';
      pill.style.width = link.offsetWidth + 'px';
      pill.style.transform = 'translateX(' + link.offsetLeft + 'px)';
      if (jump) { void pill.offsetWidth; pill.style.transition = ''; }
      pill.classList.add('ready');
    }

    wrap._resetPill = function () { place(activeLink(), true); };

    wrap.addEventListener('mouseover', function (event) {
      var link = event.target.closest && event.target.closest('a');
      if (link && wrap.contains(link)) place(link);
    });
    wrap.addEventListener('mouseleave', function () { place(activeLink()); });
    wrap.addEventListener('focusin', function (event) {
      var link = event.target.closest && event.target.closest('a');
      if (link) place(link);
    });
    wrap.addEventListener('focusout', function () { place(activeLink()); });

    requestAnimationFrame(function () { place(activeLink(), true); });
  }

  /* ---------- Pasang elemen (menu dirender ulang oleh backend.js, jadi dicek berulang) ---------- */
  function ensureUI() {
    var nav = document.getElementById('layout-nav');
    if (nav) {
      var user = nav.querySelector('.user');
      if (user) {
        var toggle = user.querySelector('.theme-toggle');
        if (!toggle) {
          user.insertBefore(makeThemeControl(), user.querySelector('#logout'));
        } else {
          bindToggle(toggle);
        }
      }
      var wrap = nav.querySelector('.menubar .wrap');
      if (wrap && !wrap.querySelector('.nav-pill')) {
        var pill = document.createElement('span');
        pill.className = 'nav-pill';
        pill.setAttribute('aria-hidden', 'true');
        wrap.insertBefore(pill, wrap.firstChild);
        wrap.parentNode.classList.add('has-pill');
        bindPill(wrap, pill);
      }
    } else if (document.body && document.getElementById('formLogin') && !document.querySelector('.theme-toggle')) {
      document.body.appendChild(makeToggle(true));
    } else {
      var existingToggle = document.querySelector('.theme-toggle');
      if (existingToggle) bindToggle(existingToggle);
    }
    syncLabels();
  }

  var queued = false;
  function schedule() {
    if (queued) return;
    queued = true;
    requestAnimationFrame(function () { queued = false; ensureUI(); });
  }
  new MutationObserver(schedule).observe(root, { childList: true, subtree: true });
  document.addEventListener('ruangbk:menu-rendered', ensureUI);
  document.addEventListener('DOMContentLoaded', function () { apply(root.getAttribute('data-theme')); ensureUI(); });

  /* ---------- Taskbar mengecil saat halaman di-scroll ---------- */
  function onScroll() { root.classList.toggle('is-scrolled', (window.pageYOffset || 0) > 8); }
  window.addEventListener('scroll', onScroll, { passive: true });
  window.addEventListener('resize', function () {
    var wrap = document.querySelector('#layout-nav .menubar .wrap');
    if (wrap && wrap._resetPill) wrap._resetPill();
  });
  window.addEventListener('load', function () {
    onScroll();
    var wrap = document.querySelector('#layout-nav .menubar .wrap');
    if (wrap && wrap._resetPill) wrap._resetPill();
  });
})();
