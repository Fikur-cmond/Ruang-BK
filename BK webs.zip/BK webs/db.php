<?php
declare(strict_types=1);

$dbHost = getenv('BK_DB_HOST') ?: '127.0.0.1';
$dbName = getenv('BK_DB_NAME') ?: 'ruang_bk';
$dbUser = getenv('BK_DB_USER') ?: 'root';
$dbPassword = getenv('BK_DB_PASSWORD') ?: '';

try {
    $pdo = new PDO(
        "mysql:host={$dbHost};dbname={$dbName};charset=utf8mb4",
        $dbUser,
        $dbPassword,
        [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false,
        ]
    );
} catch (PDOException $error) {
    error_log($error->getMessage());
    http_response_code(500);
    exit('Koneksi database gagal. Periksa konfigurasi MySQL.');
}