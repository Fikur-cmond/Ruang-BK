<?php
declare(strict_types=1);

function startAppSession(): void
{
    ini_set('session.use_strict_mode', '1');
    ini_set('session.use_only_cookies', '1');
    ini_set('session.gc_maxlifetime', '28800');
    session_set_cookie_params([
        'httponly' => true,
        'secure' => !empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off',
        'samesite' => 'Strict',
    ]);
    session_start();

    $sessionNow = time();
    if ((isset($_SESSION['last_activity']) && $sessionNow - (int) $_SESSION['last_activity'] > 1800)
        || (isset($_SESSION['created_at']) && $sessionNow - (int) $_SESSION['created_at'] > 28800)) {
        $_SESSION = [];
        session_regenerate_id(true);
    }
    $_SESSION['created_at'] ??= $sessionNow;
    $_SESSION['last_activity'] = $sessionNow;
}
