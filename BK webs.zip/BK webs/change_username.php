<?php
declare(strict_types=1);

if (PHP_SAPI !== 'cli') {
    http_response_code(404);
    exit;
}

require __DIR__ . '/db.php';

$oldUsername = 'Nadia Putri';
$newUsername = 'Faris Lagi Tidur';

if (!preg_match('/^[a-z0-9._-]{3,50}$/', $oldUsername)
    || !preg_match('/^[a-z0-9._-]{3,50}$/', $newUsername)) {
    fwrite(STDERR, "Edit nilai oldUsername dan newUsername di change_username.php, lalu jalankan: php change_username.php\n");
    exit(1);
}

if ($oldUsername === $newUsername) {
    fwrite(STDERR, "Username baru sama dengan username lama.\n");
    exit(1);
}

$query = $pdo->prepare('UPDATE users SET username = ? WHERE username = ?');
try {
    $query->execute([$newUsername, $oldUsername]);
} catch (PDOException $error) {
    if ((string) $error->getCode() === '23000') {
        fwrite(STDERR, "Username baru sudah digunakan. Pilih username lain.\n");
        exit(1);
    }
    throw $error;
}

if ($query->rowCount() !== 1) {
    fwrite(STDERR, "Username lama tidak ditemukan. Tidak ada perubahan.\n");
    exit(1);
}

echo "Username berhasil diubah dari {$oldUsername} menjadi {$newUsername}. Silakan masuk kembali.\n";